package com.example.drestrau.Activities.Manager;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.drestrau.Activities.Authentication.Register;
import com.example.drestrau.Adapters.AdapterForNewStaff;
import com.example.drestrau.Objects.users;
import com.example.drestrau.R;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

public class ManagerActivity extends AppCompatActivity {
    String rid,uid;
    Button addStaff,viewStaff,payment,food;
    boolean isAllowed=true;
    ImageView spec1,spec2,spec3;
    TextView name1,name2,name3;
    ArrayList<users> listForNewStaff;
    AdapterForNewStaff adapterForNewStaff;

DatabaseReference staffRef;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manager);

        initialiseViews();
        staffRef= FirebaseDatabase.getInstance().getReference("users");
        uid=FirebaseAuth.getInstance().getUid();
        rid=getIntent().getStringExtra("rid");
        //getRes();
        setSpeciality();

        addStaff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               if(isAllowed)
                    showDialog();
            }
        });


        viewStaff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(ManagerActivity.this, AllStaff.class);
                intent.putExtra("rid",rid);
                startActivity(intent);
            }
        });
        payment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        food.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //goto Menu Activity
                Intent intent=new Intent(ManagerActivity.this, EditMenuActivity.class);
                intent.putExtra("rid",rid);
                startActivity(intent);
            }
        });

    }

    private void initialiseViews() {
        addStaff=findViewById(R.id.manager_addStaff);
        viewStaff=findViewById(R.id.manager_viewStaff);
        payment=findViewById(R.id.manager_payment);
        food=findViewById(R.id.manager_food_menu);
        spec1=findViewById(R.id.manager_spec1);
        spec2=findViewById(R.id.manager_spec2);
        spec3=findViewById(R.id.manager_spec3);
        name1=findViewById(R.id.manager_specName1);
        name2=findViewById(R.id.manager_specName2);
        name3=findViewById(R.id.manager_specName3);
    }
    private void setSpeciality(){

        final Intent intent=new Intent(ManagerActivity.this, ManagerChooseSpecial.class);
        intent.putExtra("rid",rid);
        spec1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                intent.putExtra("pos",1);
                startActivity(intent);
            }
        });
        spec2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                intent.putExtra("pos",2);
                startActivity(intent);
            }
        });
        spec3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent.putExtra("pos",3);
                startActivity(intent);
            }
        });
        FirebaseDatabase.getInstance().getReference("restaurants").child(rid).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                switch (dataSnapshot.getKey()){
                    case "spec1":{
                                getFood(dataSnapshot.getValue(String.class),1);
                        break;
                    }
                    case "spec2":{
                        getFood(dataSnapshot.getValue(String.class),2);
                        break;
                    }
                    case "spec3":{
                        getFood(dataSnapshot.getValue(String.class),3);
                        break;
                    }
                }
            }


            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    private void getFood(String id, final int pos){
        FirebaseDatabase.getInstance().getReference("menus").child(rid).child(id).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                if(dataSnapshot.getKey().equals("picUrl")){
                    switch (pos){
                        case 1:{Glide.with(ManagerActivity.this)
                                .load(dataSnapshot.getValue(String.class))
                                .into(spec1);
                            break;
                        }
                        case 2:{Glide.with(ManagerActivity.this)
                                .load(dataSnapshot.getValue(String.class))
                                .into(spec2);
                            break;
                        }
                        case 3:{Glide.with(ManagerActivity.this)
                                .load(dataSnapshot.getValue(String.class))
                                .into(spec3);
                            break;
                        }
                    }
                }
                if(dataSnapshot.getKey().equals("name")){
                    switch (pos){
                        case 1:{name1.setText(dataSnapshot.getValue(String.class));
                            break;
                        }
                        case 2:{name2.setText(dataSnapshot.getValue(String.class));
                            break;
                        }
                        case 3:{name3.setText(dataSnapshot.getValue(String.class));
                            break;
                        }

                    }
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    /*
    private void getRes(){
        //getting the details of my restaurant
        FirebaseDatabase.getInstance().getReference("restaurants").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                RestObject obj=dataSnapshot.getValue(RestObject.class);
                if(obj.getManUid().equals(uid)){
                    rid=dataSnapshot.getKey();
                    isAllowed=true;
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    */
    private void showDialog(){
        listForNewStaff=new ArrayList<>();
        adapterForNewStaff=new AdapterForNewStaff(this,listForNewStaff);
        final AlertDialog.Builder builder=new AlertDialog.Builder(ManagerActivity.this);
        View view = null;
        view= LayoutInflater.from(ManagerActivity.this).inflate(R.layout.new_staff_dialog,null);
        builder.setView(view);


        //-----------------------------------------------------------------------------------
        final TextView nameEntered=view.findViewById(R.id.dialog_newstaffName);
        Button newId=view.findViewById(R.id.dialognewStaffAddBtn);
        ListView lv=view.findViewById(R.id.dialog_newstaff_lv);
        lv.setAdapter(adapterForNewStaff);
        nameEntered.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            if(s!=null&&s!=""){
                populateListForStaffs(s.toString());
            }else{
                listForNewStaff.clear();
            }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                users crnt=listForNewStaff.get(position);
                Intent intent=new Intent(ManagerActivity.this, addStaff.class);
                intent.putExtra("rid",rid);
                intent.putExtra("staffUid",crnt.getUid());
                startActivity(intent);
                finish();
            }
        });



        newId.setOnClickListener(new View.OnClickListener() {
                                     @Override
                                     public void onClick(View v) {
                                         //goto new id activity
                                         getAlertforExit();
                                     }
                                 });


        //------------------------------------------------------------------------------------

        builder.setTitle("New Staff");
        builder.setPositiveButton("Next", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //check in the firebase

                final String idAdded=nameEntered.getText().toString();
                staffRef.addChildEventListener(new ChildEventListener() {
                    @Override
                    public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {


                        if(dataSnapshot.getKey().equals(idAdded)){
                            Log.e("this", "onChildAdded: " );
                            //enter into another activity with the data from the user
                            Intent intent=new Intent(ManagerActivity.this, addStaff.class);
                            intent.putExtra("rid",rid);
                            intent.putExtra("staffUid",dataSnapshot.getKey());
                            startActivity(intent);
                        }
                    }

                    @Override
                    public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                    }

                    @Override
                    public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

                    }

                    @Override
                    public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

            }
        }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                builder.create().dismiss();
            }
        });
        builder.create().show();

    }
         private void populateListForStaffs(final String nameEntered) {
        listForNewStaff.clear();
        FirebaseDatabase.getInstance().getReference("users").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                users usrs=dataSnapshot.getValue(users.class);
                if (usrs != null && usrs.getName()!=null) {
                    if(usrs.getName().contains(nameEntered)){
                        if(!listForNewStaff.contains(usrs))
                        {
                            adapterForNewStaff.add(usrs);
                        }
                    }
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void getAlertforExit() {
        AlertDialog.Builder newid=new AlertDialog.Builder(ManagerActivity.this);
        newid.setTitle("Log out").setMessage("This Id will be Logged out. Are you sure you want to Continue?").setPositiveButton("Continue", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //goto new id
                FirebaseAuth.getInstance().signOut();
                Intent intent=new Intent(ManagerActivity.this, Register.class);
                startActivity(intent);
            }
        }).setNegativeButton("cancel",null);
        newid.create().show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_manager,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()){
            case R.id.action_manager_log_out:{
     //                   uploadImage();
                    FirebaseAuth.getInstance().signOut();
                finish();
                return true;
            }
            default:{
                return  super.onOptionsItemSelected(item);
            }
        }
    }
}

