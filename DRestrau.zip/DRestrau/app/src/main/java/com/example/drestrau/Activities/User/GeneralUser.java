package com.example.drestrau.Activities.User;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.drestrau.Adapters.GeneralFoodRecyclerView;
import com.example.drestrau.Objects.menuObjForFood;
import com.example.drestrau.Objects.menuObject;
import com.example.drestrau.R;
import com.example.drestrau.Objects.RestObject;
import com.example.drestrau.Adapters.resAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Random;

public class GeneralUser extends AppCompatActivity{
String uid;

FirebaseDatabase db;
DatabaseReference ref;
resAdapter adapter;

TextView address,pincode;

RecyclerView rview;
ArrayList<menuObjForFood> foodList;
GeneralFoodRecyclerView rv;

ListView listView;
ArrayList<RestObject> list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_general_user);

        initialize();

        list=new ArrayList<>();
        adapter=new resAdapter(this,list);
        listView.setAdapter(adapter);

        Intent i=getIntent();
        uid=i.getStringExtra("uid");
        db=FirebaseDatabase.getInstance();
        ref=db.getReference("restaurants");

        getDetails();
        populateList();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                RestObject current=list.get(position);
                Intent intent=new Intent(GeneralUser.this, MenuActivity.class);
                intent.putExtra("rid",current.getRid());
                startActivity(intent);
            }
        });
    }
    private void getDetails(){
        String uid=FirebaseAuth.getInstance().getUid();
        if (uid != null) {
            FirebaseDatabase.getInstance().getReference("users").child(uid).addChildEventListener(new ChildEventListener() {
                @Override
                public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                    switch (dataSnapshot.getKey()){
                        case "address1":{
                                address.setText(dataSnapshot.getValue(String.class));
                            break;
                        }
                        case "address2":{
                            address.append(" "+dataSnapshot.getValue(String.class));
                            break;
                        }
                        case "pincode":{
                            pincode.setText(String.valueOf(dataSnapshot.getValue(Long.class)));
                          //  populateList(1);
                            break;
                        }
                    }
                }

                @Override
                public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                }

                @Override
                public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

                }

                @Override
                public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

        }
    }
    private void initialize(){
        listView=findViewById(R.id.general_res_list);
        address=findViewById(R.id.general_address);
        pincode=findViewById(R.id.general_pincode);
        rview=findViewById(R.id.general_Rv1);
    }
    private void populateList(){

            ref.addChildEventListener(new ChildEventListener() {
                @Override
                public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                    RestObject object=dataSnapshot.getValue(RestObject.class);
                        adapter.add(object);

                }

                @Override
                public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                }

                @Override
                public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

                }

                @Override
                public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
            ref.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    popRecyclerView();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
    }
    private void popRecyclerView(){
        foodList=new ArrayList<>();
        rview.setHasFixedSize(true);
        AdapterView.OnItemClickListener listener=new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                menuObjForFood forFood=foodList.get(position);
                Intent intent=new Intent(GeneralUser.this,MenuActivity.class);
                intent.putExtra("rid",forFood.getRid());
                startActivity(intent);
            }
        };
        rv=new GeneralFoodRecyclerView(this,foodList,listener);
        rview.setAdapter(rv);
        Log.e("list size", "popRecyclerView: "+list.size() );
        int count=0;
        for(int i=0;i<list.size();i++){
                count++;
                final int random=new Random().nextInt(3);
                final String currRid=list.get(i).getRid();
                String currFid = null;
                switch (random){
                    case 0:{
                            currFid=list.get(i).getSpec1();
                        break;
                    }
                    case 1:{
                        currFid=list.get(i).getSpec2();
                        break;
                    }
                    case 2:{
                        currFid=list.get(i).getSpec3();
                        break;
                    }
                }
                if(currFid!=null){
                    final menuObject object = new menuObject();
                    FirebaseDatabase.getInstance().getReference("menus").child(currRid).child(currFid).addChildEventListener(new ChildEventListener() {
                        @Override
                        public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                            switch (dataSnapshot.getKey()){
                                case "fid":{
                                    object.setFid(dataSnapshot.getValue(String.class));
                                    break;
                                }
                                case "offer":{
                                    Integer val=dataSnapshot.getValue(int.class);
                                    if(val!=null) {
                                        object.setOffer(val);
                                    }else{
                                        object.setOffer(0);
                                    }
                                    break;
                                }
                                case "picUrl":{
                                    object.setPicUrl(dataSnapshot.getValue(String.class));
                                    break;
                                }
                            }
                        }

                        @Override
                        public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                        }

                        @Override
                        public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

                        }

                        @Override
                        public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });
                    FirebaseDatabase.getInstance().getReference("menus").child(currRid).child(currFid).addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                            menuObjForFood obj=new menuObjForFood(object,currRid);
                            foodList.add(obj);
                            rv.notifyDataSetChanged();
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });
                }

                if(count>=10){
                    break;
                }
            }


    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_general,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()){
            case R.id.action_signOut:{
                FirebaseAuth.getInstance().signOut();
                finish();
                return true;
            }
            case R.id.action_new_restrau:{
                    Intent intent=new Intent(GeneralUser.this, addRestrau.class);
                    startActivity(intent);
                return true;
            }
            case R.id.action_general_profile:{
                Intent intent=new Intent(GeneralUser.this, ProfileActivity.class);
                startActivity(intent);
                return true;
            }
            default:{
                return super.onOptionsItemSelected(item);
            }
        }
    }


}
