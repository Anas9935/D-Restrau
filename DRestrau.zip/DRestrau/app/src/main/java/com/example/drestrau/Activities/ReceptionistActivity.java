package com.example.drestrau.Activities;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.drestrau.Adapters.RecepAdapter;
import com.example.drestrau.Objects.RecepObject;
import com.example.drestrau.Objects.attendanceObject;
import com.example.drestrau.Objects.paymentObject;
import com.example.drestrau.Objects.selectionForChefObject;
import com.example.drestrau.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class ReceptionistActivity extends AppCompatActivity {
String rid;
ListView lv;
FloatingActionButton fab,scanAtt,scanRes,newRes;
//TextView seatNumber;
int seats;
int tableSel;
String  restNameString;
RecepAdapter adapter;
ArrayList<RecepObject> list;

IntentIntegrator qrcode;
    private String TAG="Recep";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receptionist);

        rid=getIntent().getStringExtra("rid");
        initialiseViews();

        list=new ArrayList<>();
        adapter=new RecepAdapter(this,list);
        lv.setAdapter(adapter);
        getList();
        getRestNameAndSeats();
       // getSeats();

        qrcode=new IntentIntegrator(this);

        scanRes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                qrcode.initiateScan();
            }
        });
        scanAtt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                qrcode.initiateScan();
            }
        });
        newRes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

    }
    private void getRestNameAndSeats() {
        FirebaseDatabase.getInstance().getReference("restaurants").child(rid).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
               switch (dataSnapshot.getKey()){
                   case "name":{
                       restNameString=dataSnapshot.getValue(String.class);
                       break;
                   }
                   case "seats":{
                       Integer seat=dataSnapshot.getValue(Integer.class);
                       if(seat!=null){
                           seats=seat;
                       }
                       break;
                   }
               }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void initialiseViews(){
        lv=findViewById(R.id.recep_lv);
        fab=findViewById(R.id.recep_fab);
        scanAtt=findViewById(R.id.recep_scan_atten);
        scanRes=findViewById(R.id.recep_scan_res);
        newRes=findViewById(R.id.recep_newRes);
      //  seatNumber=findViewById(R.id.recep_seatNo);
    }
    private void getList(){
        FirebaseDatabase.getInstance().getReference("payments").child(rid).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                paymentObject obj=dataSnapshot.getValue(paymentObject.class);
                RecepObject recepObject= null;
                if (obj != null) {
                    recepObject = new RecepObject(obj.getPid(),obj.getUid(),rid,obj.getTotal(),obj.getStatus(),obj.getMode(),1);
                    adapter.add(recepObject);
                    Log.e("ths", "onChildAdded: "+list.size() );
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        IntentResult result=IntentIntegrator.parseActivityResult(requestCode,resultCode,data);

        if(result!=null){
            if(result.getContents()==null){
                Toast.makeText(this, "No Proper Data Found Found", Toast.LENGTH_SHORT).show();
            }else{
                try{
                    JSONObject obj=new JSONObject(result.getContents());
                    if(obj.has("selKey")){
                        String uidObj=obj.getString("uid");
                        String ridObj=obj.getString("rid");
                        String selKeyObj=obj.getString("selKey");
                        String payKey=obj.getString("payKey");
                        long dateObj=obj.getInt("datestamp");
                        int timeObj=obj.getInt("timeindex");
                        if (ridObj.equals(rid)&&seats!=0&&restNameString!=null){
                            Toast.makeText(this,"Restaurant Id Matched",Toast.LENGTH_SHORT).show();
                            popupDialog(uidObj,ridObj,selKeyObj,payKey,dateObj,timeObj);
                        }
                    }else if(obj.has("uid")){
                        String staffUserid=obj.getString("uid");
                        String staffId=obj.getString("sid");
                        Log.e(TAG, "onActivityResult: "+"you are here" );
                        updateAttendance(staffId);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }else {
            super.onActivityResult(requestCode, resultCode, data);
        }


    }

    private void updateAttendance(final String sid)
    {
        FirebaseDatabase.getInstance().getReference("attendance").child(rid).child(sid).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                attendanceObject obj=dataSnapshot.getValue(attendanceObject.class);
                int dc;
                Log.e(TAG, "onDataChange: "+dataSnapshot.getKey() );
                if (obj != null) {
                    dc = obj.getDayCount();
                    dc+=1;
                    obj.setDayCount(dc);
                    if(dc>=obj.getMaxDayOfMonth()){
                        obj.setPayDue(1);
                    }
                    obj.setAttendenceToday(1);
                    FirebaseDatabase.getInstance().getReference("attendance").child(rid).child(sid).setValue(obj);
                    Toast.makeText(ReceptionistActivity.this, "Attendence done", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }

    private void popupDialog(String ud, String rd, final String selKey, String payKey, long date, int time){
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        View view=null;
        view= LayoutInflater.from(ReceptionistActivity.this).inflate(R.layout.scan_res_dialog,null);
        builder.setTitle("scanned result");
        builder.setView(view);
        //-------------------------------------------------------------------------------------------
        TextView name,dt,tm,restName;
        Spinner tabSel;
        name=view.findViewById(R.id.booking_name);
        dt=view.findViewById(R.id.booking_date);
        tm=view.findViewById(R.id.booking_time);
        restName=view.findViewById(R.id.booking_name_rest);
        tabSel=view.findViewById(R.id.booking_tables_spin);
        setupTableSpinner(tabSel);
        setName(name,ud);
        //matching the rd and rid
       restName.setText(restNameString);
     //   setRestName(restName,rd);
        dt.setText(getDate(date));
        String[] times=getResources().getStringArray(R.array.timeSlot);
        tm.setText(times[time]);
        //update the list
        for(RecepObject curr:list){
            if(curr.getPid().equals(payKey)){
                curr.setCustStat(0);
                adapter.notifyDataSetChanged();
                break;
            }
        }
        //final int tableSel=getTableSel(tabSel);
        //-------------------------------------------------------------------------------------------
        builder.setPositiveButton("Notify Cook", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                notifyCook(tableSel,selKey);
            }
        }).setNegativeButton("Cancel",null);
        builder.create().show();
    }

    private void setupTableSpinner(Spinner tabSel) {
        Integer[] tables=new Integer[seats];
        for(int i=0;i<seats;i++){
            tables[i]=i+1;
        }
        ArrayAdapter<Integer> adapter= new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,tables);
        tabSel.setAdapter(adapter);
        tabSel.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                tableSel=position+1;
                Toast.makeText(ReceptionistActivity.this, "table selected is"+position+1, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            tableSel=0;
            }
        });
    }


    private void notifyCook(final int tabl, final String sid){
        FirebaseDatabase.getInstance().getReference("selections").child(rid).child(sid).child("choice").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String ch=dataSnapshot.getValue(String.class);
                if(ch!=null)
                {selectionForChefObject obj=new selectionForChefObject(tabl,ch,sid);
                    FirebaseDatabase.getInstance().getReference("selectionForChef").child(rid).push().setValue(obj);
                    Toast.makeText(ReceptionistActivity.this, "Cook Is Notified", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(ReceptionistActivity.this,"No Such Order Exists",Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    private void setName(final TextView name, String uid){
        FirebaseDatabase.getInstance().getReference("users").child(uid).child("name").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String n=dataSnapshot.getValue(String.class);
                if(n!=null){
                    name.setText(n);
                }else{
                    name.setText("Customer");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private String getDate(long timeS){
        SimpleDateFormat format=new SimpleDateFormat("dd-mm-yyyy");
        return format.format(new Date(timeS*1000));
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_recep,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()){
            case R.id.action_recep_log_out:{
                FirebaseAuth.getInstance().signOut();
                finish();
                return true;
            }
            case R.id.action_recep_manual_att:{
                Intent intent=new Intent(ReceptionistActivity.this,ManualAttendenceActivity.class);
                intent.putExtra("rid",rid);
                startActivity(intent);
                return true;
            }
            default:{
                return  super.onOptionsItemSelected(item);
            }
        }
    }
}
