package com.example.drestrau.Activities;

import java.text.SimpleDateFormat;
import java.util.Date;

public class utilityClass {

    public static String getTime(long timestamp){
        SimpleDateFormat formatter=new SimpleDateFormat("HH:mm");
        return formatter.format(new Date(timestamp*1000));
    }
    public static String getDate(long timestamp){
        SimpleDateFormat formatter=new SimpleDateFormat("dd/mm/yyyy");
        return formatter.format(new Date(timestamp*1000));
    }
}
