package com.example.drestrau.Activities.Manager;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.drestrau.Activities.User.ProfileActivity;
import com.example.drestrau.Adapters.allStaffAdapter;
import com.example.drestrau.Objects.staffForListObject;
import com.example.drestrau.Objects.staffObject;
import com.example.drestrau.R;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class AllStaff extends AppCompatActivity {
ListView lv;
allStaffAdapter adapter;
ArrayList<staffForListObject> list;

String rid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_staff);

        rid=getIntent().getStringExtra("rid");

        initialiseViews();
        list=new ArrayList<>();
        adapter=new allStaffAdapter(this,list);
        lv.setAdapter(adapter);
        getListItems();
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent=new Intent(AllStaff.this, ProfileActivity.class);     //opening the profile of the staff
                intent.putExtra("rid",rid);
                intent.putExtra("staffId",list.get(position).getStaffId());
                startActivity(intent);
            }

        });
    }
    private void initialiseViews(){
        lv=findViewById(R.id.all_staff_listview);
    }
    private void getListItems(){
        FirebaseDatabase.getInstance().getReference("staffs").child(rid).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                staffObject object=dataSnapshot.getValue(staffObject.class);
                String name=object.getName1()+" "+object.getName2()+" "+object.getName3();
                staffForListObject staff=new staffForListObject(name,null,object.getSid(),object.getUid(),object.getContact1(),object.getDesignation());
                staff.setPicUrl(object.getPicUrl());
               getPaydue(staff);
                //getPPURL(object.getUid(),staff);
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
    private void getPaydue(final staffForListObject object) {
        FirebaseDatabase.getInstance().getReference("attendance").child(rid).child(object.getStaffUid()).child("payDue").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Integer integer=dataSnapshot.getValue(Integer.class);
                if(integer!=null){
                    object.setPaydue(integer);
                }
                adapter.add(object);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
