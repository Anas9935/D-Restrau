package com.example.drestrau.Adapters;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.drestrau.Objects.menuObject;
import com.example.drestrau.Objects.quantatySelected;
import com.example.drestrau.R;

import java.util.ArrayList;

import static android.support.constraint.Constraints.TAG;

public class menuAdapter extends ArrayAdapter<menuObject> {
    ArrayList<menuObject> list;

 //   ArrayList<Integer> foodId;
   // ArrayList<Integer> quantity;
    //int a=0;

    ArrayList<quantatySelected> quantity;
    public menuAdapter( Context context, ArrayList<menuObject> l) {
        super(context, 0,l);
        list=l;

//        foodId=new ArrayList<>();
        quantity=new ArrayList<>();

    }



    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View view=convertView;

        if(view==null){
            view= LayoutInflater.from(getContext()).inflate(R.layout.menu_todo,parent,false);
        }
        ImageView imv,veg;
        final TextView name,info,price,ad,min,quan,offer;
        final Button add;
        RatingBar bar;
        final LinearLayout menuadd;
        imv=view.findViewById(R.id.menuimg);
        veg=view.findViewById(R.id.menuveg);
        name=view.findViewById(R.id.menuname);
        info=view.findViewById(R.id.menuInfo);
        price=view.findViewById(R.id.menuprice);
        ad=view.findViewById(R.id.menuaddplus);
        min=view.findViewById(R.id.menuaddminus);
        quan=view.findViewById(R.id.menuqty);
        add=view.findViewById(R.id.menuadd);
        offer=view.findViewById(R.id.menuoffer);
        menuadd=view.findViewById(R.id.menuaddlayout);
        bar=view.findViewById(R.id.menu_rating);

        final menuObject current=list.get(position);

        final Boolean[] addIsClose = {true};
        final int[] qty = {1};

        if(current.getPicUrl()!=null){
            Glide.with(getContext()).load(current.getPicUrl())
                    .into(imv);
        }
        int type=current.getType();
        if(type==0){
            veg.setImageResource(R.drawable.veg);
        }else{
            veg.setImageResource(R.drawable.nonveg);
        }
        name.setText(current.getName());
        info.setText(current.getInfo());
        price.setText(String.valueOf(current.getPrice()));
        offer.setText(String.valueOf(current.getOffer()));
        bar.setRating(current.getRating());
        final quantatySelected ifsel=new quantatySelected(current.getFid(),0);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(addIsClose[0]){
                    addIsClose[0] =false;
                   // foodId.add(current.getFid());
                    quantity.add(ifsel);
                    ifsel.setQuantity(ifsel.getQuantity()+1);
                    add.setVisibility(View.INVISIBLE);
                    menuadd.setVisibility(View.VISIBLE);
                }
            }
        });
        ad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(qty[0] <10){
                    qty[0]++;
                    ifsel.setQuantity(ifsel.getQuantity()+1);
                    quan.setText(String.valueOf(qty[0]));
                }
                else{
                    Toast.makeText(getContext(), "Please make another order for additional quantity", Toast.LENGTH_SHORT).show();
                }
            }
        });
        min.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(qty[0] >1){
                    qty[0]--;
                    ifsel.setQuantity(ifsel.getQuantity()-1);
                    quan.setText(String.valueOf(qty[0]));
                }else{
                    addIsClose[0] =true;
                    quantity.remove(quantity.indexOf(ifsel));
                    add.setVisibility(View.VISIBLE);
                    menuadd.setVisibility(View.INVISIBLE);
                }
            }
        });

        return view;
    }

    public String generateString(){
        String ch;
        StringBuilder s=new StringBuilder(500);
        for(int i=0;i<quantity.size();i++){

                s.append(quantity.get(i).getFoodId());
                s.append("("+quantity.get(i).getQuantity()+") ");


        }
        Log.e(TAG, "generateString: "+s.toString() );
        ch=s.toString();
        return ch;
    }

}
